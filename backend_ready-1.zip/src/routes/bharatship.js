import express from "express";
import axios from "axios";

const router = express.Router();

router.post("/token", async (req,res)=>{
  try{
    const { email, password } = req.body;
    const r = await axios.post("https://app.bharatship.com/api/auth/login",{email,password});
    res.send(r.data);
  }catch(err){
    res.status(500).send({error:"Bharatship Error", details: err.response?.data});
  }
});

export default router;
