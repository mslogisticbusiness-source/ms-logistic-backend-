import express from "express";
import bharatship from "./bharatship.js";
import nimbus from "./nimbus.js";

const router = express.Router();

router.use("/bharatship", bharatship);
router.use("/nimbus", nimbus);

export default router;
