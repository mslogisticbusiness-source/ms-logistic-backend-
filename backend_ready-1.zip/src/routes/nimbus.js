import express from "express";
import axios from "axios";

const router = express.Router();

router.post("/token", async (req,res)=>{
  try{
    const { email, password } = req.body;
    const r = await axios.post("https://api.nimbuspost.com/api/v1/auth/login",{email,password});
    res.send(r.data);
  }catch(err){
    res.status(500).send({error:"Nimbus Error", details: err.response?.data});
  }
});

export default router;
